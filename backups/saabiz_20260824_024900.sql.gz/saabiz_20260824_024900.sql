--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: CommissionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CommissionStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'PAID',
    'CANCELLED'
);


--
-- Name: DiscountType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DiscountType" AS ENUM (
    'PERCENTAGE',
    'FIXED'
);


--
-- Name: Interval; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Interval" AS ENUM (
    'ONETIME',
    'MONTHLY',
    'ANNUAL'
);


--
-- Name: PayoutStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PayoutStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'SELLER',
    'AFFILIATE',
    'CUSTOMER'
);


--
-- Name: SubscriptionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubscriptionStatus" AS ENUM (
    'ACTIVE',
    'CANCELED',
    'PAST_DUE',
    'TRIALING',
    'IN_GRACE_PERIOD'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Affiliate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Affiliate" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "affiliateCode" text NOT NULL,
    "commissionRate" double precision DEFAULT 0.1 NOT NULL,
    "totalEarnings" double precision DEFAULT 0 NOT NULL,
    "pendingPayout" double precision DEFAULT 0 NOT NULL,
    "totalReferrals" integer DEFAULT 0 NOT NULL,
    "totalCommission" double precision DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AffiliateCommission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AffiliateCommission" (
    id text NOT NULL,
    "affiliateId" text NOT NULL,
    "transactionId" text,
    "productId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status public."CommissionStatus" DEFAULT 'PENDING'::public."CommissionStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "paidAt" timestamp(3) without time zone
);


--
-- Name: AffiliateLink; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AffiliateLink" (
    id text NOT NULL,
    "affiliateId" text NOT NULL,
    "productId" text NOT NULL,
    code text NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    conversions integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: AffiliatePayout; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AffiliatePayout" (
    id text NOT NULL,
    "affiliateId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status public."PayoutStatus" DEFAULT 'PENDING'::public."PayoutStatus" NOT NULL,
    reference text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "processedAt" timestamp(3) without time zone
);


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "userId" text,
    "userEmail" text,
    action text NOT NULL,
    resource text,
    "resourceId" text,
    details jsonb,
    "ipAddress" text,
    "userAgent" text,
    status text DEFAULT 'success'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: BotSubmission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BotSubmission" (
    id text NOT NULL,
    form text NOT NULL,
    email text,
    "ipAddress" text,
    "userAgent" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Domain; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Domain" (
    id text NOT NULL,
    host text NOT NULL,
    "tenantId" text NOT NULL,
    "isPrimary" boolean DEFAULT false NOT NULL,
    "isVerified" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Honeypot; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Honeypot" (
    id text NOT NULL,
    "productId" text NOT NULL,
    key text NOT NULL,
    label text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: HoneypotHit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HoneypotHit" (
    id text NOT NULL,
    "honeypotId" text NOT NULL,
    endpoint text NOT NULL,
    "machineId" text,
    domain text,
    "ipAddress" text,
    "userAgent" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: License; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."License" (
    id text NOT NULL,
    "productId" text NOT NULL,
    key text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "transactionId" text,
    "buyerEmail" text,
    "subscriptionId" text,
    activations integer DEFAULT 0 NOT NULL,
    "machineId" text
);


--
-- Name: Plan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Plan" (
    id text NOT NULL,
    "productId" text NOT NULL,
    name text NOT NULL,
    price double precision NOT NULL,
    "interval" public."Interval" DEFAULT 'ONETIME'::public."Interval" NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "maxActivations" integer DEFAULT 1 NOT NULL
);


--
-- Name: PlatformConfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PlatformConfig" (
    id text NOT NULL,
    "paystackPublicKey" text,
    "paystackSecretKey" text,
    "flutterwavePublicKey" text,
    "flutterwaveSecretKey" text,
    "flutterwaveEncryptionKey" text,
    "webhookSecret" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "flutterwaveActive" boolean DEFAULT false NOT NULL,
    "paystackActive" boolean DEFAULT false NOT NULL,
    "tenantId" text
);


--
-- Name: Product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    "sellerId" text NOT NULL,
    name text NOT NULL,
    description text,
    "freezeReason" text,
    "isFrozen" boolean DEFAULT false NOT NULL,
    "downloadUrl" text,
    version text
);


--
-- Name: Promotion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Promotion" (
    id text NOT NULL,
    code text NOT NULL,
    description text,
    "discountType" public."DiscountType" DEFAULT 'PERCENTAGE'::public."DiscountType" NOT NULL,
    "discountValue" double precision NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "maxUses" integer,
    uses integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Seller; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Seller" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "businessName" text,
    "payoutEmail" text,
    "payoutGateway" text,
    "pendingPayout" double precision DEFAULT 0 NOT NULL,
    "totalEarnings" double precision DEFAULT 0 NOT NULL,
    "tenantId" text
);


--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "customerEmail" text NOT NULL,
    "productId" text NOT NULL,
    "planId" text NOT NULL,
    gateway text NOT NULL,
    "gatewaySubscriptionId" text,
    status public."SubscriptionStatus" DEFAULT 'ACTIVE'::public."SubscriptionStatus" NOT NULL,
    "currentPeriodStart" timestamp(3) without time zone NOT NULL,
    "currentPeriodEnd" timestamp(3) without time zone NOT NULL,
    "cancelAtPeriodEnd" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "graceUntil" timestamp(3) without time zone,
    "paymentFailedAt" timestamp(3) without time zone,
    "lastDunningSentAt" timestamp(3) without time zone
);


--
-- Name: Tenant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Tenant" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    settings jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Transaction" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "planId" text NOT NULL,
    reference text NOT NULL,
    gateway text NOT NULL,
    amount double precision NOT NULL,
    status text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "affiliateId" text,
    "buyerEmail" text,
    currency text DEFAULT 'USD'::text NOT NULL,
    "platformFee" double precision DEFAULT 0 NOT NULL,
    "sellerEarnings" double precision DEFAULT 0 NOT NULL,
    "subscriptionId" text,
    "promotionId" text
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    role public."Role" DEFAULT 'SELLER'::public."Role" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "emailVerifyToken" text,
    "isEmailVerified" boolean DEFAULT false NOT NULL,
    "passwordResetExpires" timestamp(3) without time zone,
    "passwordResetToken" text
);


--
-- Name: WebhookEvent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WebhookEvent" (
    id text NOT NULL,
    gateway text NOT NULL,
    "eventName" text NOT NULL,
    reference text,
    signature text,
    "rawBody" text,
    payload jsonb NOT NULL,
    status text DEFAULT 'processing'::text NOT NULL,
    error text,
    "configId" text,
    "replayCount" integer DEFAULT 0 NOT NULL,
    "lastReplayAt" timestamp(3) without time zone,
    "lastReplayStatus" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: Affiliate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Affiliate" (id, "userId", "affiliateCode", "commissionRate", "totalEarnings", "pendingPayout", "totalReferrals", "totalCommission", "createdAt", "updatedAt") FROM stdin;
2afa8240-1b4a-480f-b97d-ff75a1c2b162	70982e59-9749-46d3-94b6-0272fc17b440	AFFILIATE2024	0.15	0	0	0	0	2026-08-20 14:36:00.209	2026-08-20 14:36:00.209
\.


--
-- Data for Name: AffiliateCommission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AffiliateCommission" (id, "affiliateId", "transactionId", "productId", amount, currency, status, "createdAt", "paidAt") FROM stdin;
\.


--
-- Data for Name: AffiliateLink; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AffiliateLink" (id, "affiliateId", "productId", code, clicks, conversions, "createdAt", "isActive") FROM stdin;
\.


--
-- Data for Name: AffiliatePayout; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AffiliatePayout" (id, "affiliateId", amount, currency, status, reference, "createdAt", "processedAt") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLog" (id, "userId", "userEmail", action, resource, "resourceId", details, "ipAddress", "userAgent", status, "createdAt") FROM stdin;
b55d507e-4c63-478f-98d3-76e40bc7f720	\N	\N	HONEYPOT_HIT	license	SAABIZ-H0N3YP0T-ACME01	{"endpoint": "verify", "productId": "seed-acme-analytics"}	::1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.22000.2538	warning	2026-08-23 13:22:03.316
25c5bd24-1eb6-466f-9dcc-bb6daa1af322	\N	\N	HONEYPOT_HIT	license	SAABIZ-H0N3YP0T-ACME01	{"domain": "pirate-site-xyz.com", "endpoint": "ota-validate", "machineId": "MACHINE-PIRATE-001", "productId": "seed-acme-analytics"}	::1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.22000.2538	warning	2026-08-23 13:22:08.845
cadf6f4f-baa7-455d-9277-f89a5a34740f	\N	\N	HONEYPOT_HIT	license	SAABIZ-H0N3YP0T-ACME01	{"endpoint": "ota-check", "productId": "seed-acme-analytics"}	::1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.22000.2538	warning	2026-08-23 13:22:09.162
a29f210a-b6ac-4f2e-89fb-cf651c3538ca	\N	\N	BOT_SUBMISSION	form	register	{"email": "spam-bot@evil.com"}	::1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.22000.2538	warning	2026-08-23 13:22:57.928
9b76cbd8-d268-4c8a-9220-e6368df86721	\N	\N	TENANT_CREATE	tenant	ef62a637-58d1-4ebf-974e-acbc6cb11330	{"slug": "initech", "primaryDomain": null}	\N	\N	success	2026-08-24 00:56:54.653
f5c941a9-6892-49f4-8f3b-7adec6f2e694	\N	\N	PAYMENT_FAILED	subscription	cf3f1816-1f08-4f8a-873a-d5e6865ff9a4	{"gateway": "paystack", "productId": "seed-acme-analytics", "graceUntil": "2026-08-31T01:04:54.888Z"}	\N	\N	warning	2026-08-24 01:04:54.914
374bbc8d-e705-40ea-932c-c0bf83ba2efb	\N	\N	LICENSE_REVOKE	license	SAABIZ-DF6DF82F0BB1AF75	{"sellerId": "3364cf5e-eb73-40d3-bf8b-a5b5e9c5c851"}	\N	\N	success	2026-08-24 01:05:45.65
\.


--
-- Data for Name: BotSubmission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BotSubmission" (id, form, email, "ipAddress", "userAgent", metadata, "createdAt") FROM stdin;
ce52e23e-c683-45e6-9243-66a25e0a045d	register	spam-bot@evil.com	::1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.22000.2538	\N	2026-08-23 13:22:57.896
\.


--
-- Data for Name: Domain; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Domain" (id, host, "tenantId", "isPrimary", "isVerified", "createdAt") FROM stdin;
773ac3f5-c9df-4cd2-8e62-8aff533f78cf	acme.saabiz.com	95b46f5a-3bf3-423a-99c6-d00cc502a81e	t	t	2026-08-20 14:35:51.275
a87a37bb-ef4e-410d-b477-d4ea639160bb	globex.saabiz.com	a2e9b3db-74a2-4387-ad3d-c5c7ef2ab22f	t	t	2026-08-20 14:35:51.459
ae901dd1-8b5d-406e-9531-65e848d95d8b	initech.saabiz.com	ef62a637-58d1-4ebf-974e-acbc6cb11330	f	t	2026-08-24 00:56:54.799
43a23076-86f6-4188-ab8b-7c803e1f1fe9	shop.initech.example	ef62a637-58d1-4ebf-974e-acbc6cb11330	t	t	2026-08-24 00:56:54.932
\.


--
-- Data for Name: Honeypot; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Honeypot" (id, "productId", key, label, "isActive", "createdAt") FROM stdin;
3140dc06-b910-45f5-a7b0-deee86562e0f	seed-acme-analytics	SAABIZ-H0N3YP0T-ACME01	Planted in leaked v1.2.0 build (forum)	t	2026-08-23 12:47:28.418
0a75bf22-037e-4754-9bf7-8ee212e39f49	seed-globex-backup	SAABIZ-H0N3YP0T-GLBX01	Planted in leaked v3.4.2 build (torrent)	t	2026-08-23 12:47:28.621
\.


--
-- Data for Name: HoneypotHit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."HoneypotHit" (id, "honeypotId", endpoint, "machineId", domain, "ipAddress", "userAgent", metadata, "createdAt") FROM stdin;
de9cebe1-20f7-408a-b493-2f4379749e61	3140dc06-b910-45f5-a7b0-deee86562e0f	verify	\N	\N	::1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.22000.2538	\N	2026-08-23 13:22:02.049
6b9daa21-635c-4995-9547-bc9c242e2aff	3140dc06-b910-45f5-a7b0-deee86562e0f	ota-validate	MACHINE-PIRATE-001	pirate-site-xyz.com	::1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.22000.2538	\N	2026-08-23 13:22:08.818
e221e003-61fa-415a-8752-62ce58bb9faa	3140dc06-b910-45f5-a7b0-deee86562e0f	ota-check	\N	\N	::1	Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.22000.2538	{"currentVersion": "1.1.0"}	2026-08-23 13:22:09.146
\.


--
-- Data for Name: License; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."License" (id, "productId", key, active, "expiresAt", "transactionId", "buyerEmail", "subscriptionId", activations, "machineId") FROM stdin;
28637894-126f-462f-810f-065ca725e01b	seed-acme-analytics	SAABIZ-DF6DF82F0BB1AF75	t	2026-09-23 01:04:54.448	3f5cdd68-ec49-4671-af22-5b423536829e	roundup-test@example.com	cf3f1816-1f08-4f8a-873a-d5e6865ff9a4	0	\N
\.


--
-- Data for Name: Plan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Plan" (id, "productId", name, price, "interval", "isDefault", "maxActivations") FROM stdin;
seed-acme-analytics-basic	seed-acme-analytics	Basic	9.99	MONTHLY	t	1
seed-acme-analytics-pro	seed-acme-analytics	Pro	29.99	MONTHLY	f	5
seed-acme-analytics-enterprise	seed-acme-analytics	Enterprise	99.99	ANNUAL	f	0
seed-acme-email-starter	seed-acme-email	Starter	19.99	MONTHLY	t	1
seed-globex-backup-solo	seed-globex-backup	Solo	14.99	MONTHLY	t	1
seed-globex-backup-team	seed-globex-backup	Team	49.99	ANNUAL	f	10
\.


--
-- Data for Name: PlatformConfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PlatformConfig" (id, "paystackPublicKey", "paystackSecretKey", "flutterwavePublicKey", "flutterwaveSecretKey", "flutterwaveEncryptionKey", "webhookSecret", "updatedAt", "flutterwaveActive", "paystackActive", "tenantId") FROM stdin;
seed-platform-payment-config	pk_test_placeholder	sk_test_placeholder	FLWPUBK_TEST_placeholder	FLWSECK_TEST_placeholder	FLWSECK_TEST_placeholder_enc	\N	2026-08-20 14:36:00.712	f	f	\N
seed-acme-payment-config	pk_test_placeholder	sk_test_placeholder	\N	\N	\N	\N	2026-08-20 14:36:00.779	f	f	95b46f5a-3bf3-423a-99c6-d00cc502a81e
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Product" (id, "sellerId", name, description, "freezeReason", "isFrozen", "downloadUrl", version) FROM stdin;
seed-acme-analytics	3364cf5e-eb73-40d3-bf8b-a5b5e9c5c851	SaaS Analytics Pro	Funnel analytics, retention cohorts and revenue tracking for SaaS teams.	\N	f	https://acme.saabiz.com/downloads/saas-analytics-pro.zip	1.2.0
seed-acme-email	3364cf5e-eb73-40d3-bf8b-a5b5e9c5c851	Email Marketing Suite	Automated email campaigns, drip sequences and audience segmentation.	\N	f	https://acme.saabiz.com/downloads/email-marketing-suite.zip	2.0.1
seed-globex-backup	2db63c64-68ac-49d3-b042-9115602c062f	Cloud Backup Pro	Automated off-site backups with one-click restore for small businesses.	\N	f	https://globex.saabiz.com/downloads/cloud-backup-pro.zip	3.4.2
\.


--
-- Data for Name: Promotion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Promotion" (id, code, description, "discountType", "discountValue", "startDate", "endDate", "isActive", "maxUses", uses, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Seller; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Seller" (id, "userId", "businessName", "payoutEmail", "payoutGateway", "pendingPayout", "totalEarnings", "tenantId") FROM stdin;
4424c809-161a-417d-b6f8-6bc13b92e10e	8513b257-d556-49a7-87cf-e8250989ad1d	Test Software Co	seller@saabiz.com	paystack	0	0	\N
3364cf5e-eb73-40d3-bf8b-a5b5e9c5c851	9edad56b-a6ab-40ca-95c9-67d10a0bb3cf	Acme Software	acme@saabiz.com	paystack	0	0	95b46f5a-3bf3-423a-99c6-d00cc502a81e
2db63c64-68ac-49d3-b042-9115602c062f	234627bb-83cc-4c5f-b310-d0818bbf9003	Globex Digital	globex@saabiz.com	flutterwave	0	0	a2e9b3db-74a2-4387-ad3d-c5c7ef2ab22f
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Subscription" (id, "customerEmail", "productId", "planId", gateway, "gatewaySubscriptionId", status, "currentPeriodStart", "currentPeriodEnd", "cancelAtPeriodEnd", "createdAt", "updatedAt", "graceUntil", "paymentFailedAt", "lastDunningSentAt") FROM stdin;
cf3f1816-1f08-4f8a-873a-d5e6865ff9a4	roundup-test@example.com	seed-acme-analytics	seed-acme-analytics-basic	paystack	paystack_test_roundup_001	IN_GRACE_PERIOD	2026-12-22 00:57:22.114	2027-01-21 00:57:22.114	f	2026-08-24 00:57:22.117	2026-08-24 01:04:54.89	2026-08-31 01:04:54.888	2026-08-24 01:04:54.888	\N
\.


--
-- Data for Name: Tenant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Tenant" (id, name, slug, "isActive", settings, "createdAt", "updatedAt") FROM stdin;
95b46f5a-3bf3-423a-99c6-d00cc502a81e	Acme Software	acme	t	{"logoUrl": "", "tagline": "Software that scales with your business", "currency": "NGN", "primaryColor": "#7c3aed"}	2026-08-20 14:35:51.121	2026-08-20 14:35:51.121
a2e9b3db-74a2-4387-ad3d-c5c7ef2ab22f	Globex Digital	globex	t	{"logoUrl": "", "tagline": "Reliable digital tools for modern teams", "currency": "NGN", "primaryColor": "#0ea5e9"}	2026-08-20 14:35:51.438	2026-08-20 14:35:51.438
ef62a637-58d1-4ebf-974e-acbc6cb11330	Initech Holdings	initech	f	{"tagline": "TPS reports done right", "primaryColor": "#ec4899"}	2026-08-24 00:56:54.51	2026-08-24 00:56:55.956
\.


--
-- Data for Name: Transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Transaction" (id, "productId", "planId", reference, gateway, amount, status, "createdAt", "updatedAt", "affiliateId", "buyerEmail", currency, "platformFee", "sellerEarnings", "subscriptionId", "promotionId") FROM stdin;
3f5cdd68-ec49-4671-af22-5b423536829e	seed-acme-analytics	seed-acme-analytics-basic	paystack_test_roundup_001	paystack	2999	success	2026-08-24 01:04:54.433	2026-08-24 01:04:54.433	\N	roundup-test@example.com	USD	299.9	2699.1	cf3f1816-1f08-4f8a-873a-d5e6865ff9a4	\N
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, password, role, "createdAt", "updatedAt", "emailVerifyToken", "isEmailVerified", "passwordResetExpires", "passwordResetToken") FROM stdin;
1992a2ea-cf58-4c28-a810-bb4e433ea4da	admin@saabiz.com	$2b$12$JNrR6zLLciV6BCCS5VyLe.aJjx0I9O3FYRlt5xH6CBPVbBeiHHHGG	ADMIN	2026-08-20 14:35:45.208	2026-08-20 14:35:45.208	\N	t	\N	\N
8513b257-d556-49a7-87cf-e8250989ad1d	seller@saabiz.com	$2b$12$mkHk2KVGQ1UIAUFazsFSdOclGvFytR2TfZ2R6FmN53wFku1Tohu82	SELLER	2026-08-20 14:35:50.722	2026-08-20 14:35:50.722	\N	t	\N	\N
9edad56b-a6ab-40ca-95c9-67d10a0bb3cf	acme@saabiz.com	$2b$12$mkHk2KVGQ1UIAUFazsFSdOclGvFytR2TfZ2R6FmN53wFku1Tohu82	SELLER	2026-08-20 14:35:51.389	2026-08-20 14:35:51.389	\N	t	\N	\N
234627bb-83cc-4c5f-b310-d0818bbf9003	globex@saabiz.com	$2b$12$mkHk2KVGQ1UIAUFazsFSdOclGvFytR2TfZ2R6FmN53wFku1Tohu82	SELLER	2026-08-20 14:35:51.474	2026-08-20 14:35:51.474	\N	t	\N	\N
35818226-ae54-4d77-931a-27f64f5c7ea2	customer@saabiz.com	$2b$12$kvZFQAXa2vaSp1P72IofpOBfD6ePcCzoj9tUHq5ME0f/BXXtq2ZKS	CUSTOMER	2026-08-20 14:35:54.93	2026-08-20 14:35:54.93	\N	t	\N	\N
70982e59-9749-46d3-94b6-0272fc17b440	affiliate@saabiz.com	$2b$12$1iXn9/KPHXLtNWGSu9AhmuY1nH7swbdWAvby/RZ9gwkWNbAGgZX6u	AFFILIATE	2026-08-20 14:36:00.209	2026-08-20 14:36:00.209	\N	t	\N	\N
\.


--
-- Data for Name: WebhookEvent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WebhookEvent" (id, gateway, "eventName", reference, signature, "rawBody", payload, status, error, "configId", "replayCount", "lastReplayAt", "lastReplayStatus", "createdAt") FROM stdin;
3a2bd771-c4ff-4606-b198-c4afdd565c88	paystack	charge.success	paystack_test_roundup_001	badsig	{\r\n    "event":  "charge.success",\r\n    "data":  {\r\n                 "reference":  "paystack_test_roundup_001",\r\n                 "currency":  "NGN",\r\n                 "amount":  299900,\r\n                 "customer":  {\r\n                                  "email":  "roundup-test@example.com"\r\n                              },\r\n                 "metadata":  {\r\n                                  "affiliateCode":  "",\r\n                                  "productId":  "seed-acme-analytics",\r\n                                  "planId":  "seed-acme-analytics-basic"\r\n                              }\r\n             }\r\n}	{"data": {"amount": 299900, "currency": "NGN", "customer": {"email": "roundup-test@example.com"}, "metadata": {"planId": "seed-acme-analytics-basic", "productId": "seed-acme-analytics", "affiliateCode": ""}, "reference": "paystack_test_roundup_001"}, "event": "charge.success"}	failed	Invalid Paystack signature	\N	0	\N	\N	2026-08-24 00:57:11.083
d6945199-dcec-40c2-991d-f66c17512659	paystack	charge.success	paystack_test_roundup_001	1aa30cc845c6da37308f5f0e518e57658674ffa06f3c687795f1224fc6af9209ce5e77a5832367fe95ca265319c84c035eba4f3b1c4d8a74e544321029d4ed12	{\r\n    "event":  "charge.success",\r\n    "data":  {\r\n                 "reference":  "paystack_test_roundup_001",\r\n                 "currency":  "NGN",\r\n                 "amount":  299900,\r\n                 "customer":  {\r\n                                  "email":  "roundup-test@example.com"\r\n                              },\r\n                 "metadata":  {\r\n                                  "affiliateCode":  "",\r\n                                  "productId":  "seed-acme-analytics",\r\n                                  "planId":  "seed-acme-analytics-basic"\r\n                              }\r\n             }\r\n}	{"data": {"amount": 299900, "currency": "NGN", "customer": {"email": "roundup-test@example.com"}, "metadata": {"planId": "seed-acme-analytics-basic", "productId": "seed-acme-analytics", "affiliateCode": ""}, "reference": "paystack_test_roundup_001"}, "event": "charge.success"}	failed	\nInvalid `this.prisma.transaction.create()` invocation in\nC:\\Users\\jomea\\Saarbiz\\saabiz\\dist\\apps\\api\\src\\app\\webhooks\\webhooks.service.js:266:63\n\n  263 if (affiliateId) {\n  264     transactionData.affiliateId = affiliateId;\n  265 }\n→ 266 const transaction = await this.prisma.transaction.create({\n        data: {\n          reference: "paystack_test_roundup_001",\n          amount: 2999,\n          gateway: "paystack",\n          status: "success",\n          buyerEmail: "roundup-test@example.com",\n          product: {\n            connect: {\n              id: "seed-acme-analytics"\n            }\n          },\n          plan: {\n            connect: {\n              id: "seed-acme-analytics-basic"\n            }\n          },\n          platformFee: 299.90000000000003,\n          sellerEarnings: 2699.1,\n          subscriptionId: "cf3f1816-1f08-4f8a-873a-d5e6865ff9a4",\n          ~~~~~~~~~~~~~~\n      ?   id?: String,\n      ?   currency?: String,\n      ?   affiliateId?: String | Null,\n      ?   createdAt?: DateTime,\n      ?   updatedAt?: DateTime,\n      ?   subscription?: SubscriptionCreateNestedOneWithoutTransactionsInput,\n      ?   license?: LicenseCreateNestedOneWithoutTransactionInput,\n      ?   affiliateCommission?: AffiliateCommissionCreateNestedOneWithoutTransactionInput,\n      ?   promotion?: PromotionCreateNestedOneWithoutTransactionsInput\n        }\n      })\n\nUnknown argument `subscriptionId`. Did you mean `subscription`? Available options are marked with ?.	\N	0	\N	\N	2026-08-24 00:57:21.978
9d3f3ef8-d756-4eff-b6ba-1774190d0141	paystack	charge.failed	paystack_test_roundup_001	697a9f8d1ca3ade9ed4e31bd5f21a87b664d7cdd415720ccfad990e410fa91375b947f5aaeb2974d7f1e954df3e4a0826ad5904233ae9d3f104666e531a89a57	{\r\n    "event":  "charge.failed",\r\n    "data":  {\r\n                 "reference":  "paystack_test_roundup_001"\r\n             }\r\n}	{"data": {"reference": "paystack_test_roundup_001"}, "event": "charge.failed"}	success	\N	\N	0	\N	\N	2026-08-24 01:04:54.849
49663658-a5c8-454f-838a-c69cdc7057f8	paystack	charge.success	paystack_test_roundup_001	1aa30cc845c6da37308f5f0e518e57658674ffa06f3c687795f1224fc6af9209ce5e77a5832367fe95ca265319c84c035eba4f3b1c4d8a74e544321029d4ed12	{\r\n    "event":  "charge.success",\r\n    "data":  {\r\n                 "reference":  "paystack_test_roundup_001",\r\n                 "currency":  "NGN",\r\n                 "amount":  299900,\r\n                 "customer":  {\r\n                                  "email":  "roundup-test@example.com"\r\n                              },\r\n                 "metadata":  {\r\n                                  "affiliateCode":  "",\r\n                                  "productId":  "seed-acme-analytics",\r\n                                  "planId":  "seed-acme-analytics-basic"\r\n                              }\r\n             }\r\n}	{"data": {"amount": 299900, "currency": "NGN", "customer": {"email": "roundup-test@example.com"}, "metadata": {"planId": "seed-acme-analytics-basic", "productId": "seed-acme-analytics", "affiliateCode": ""}, "reference": "paystack_test_roundup_001"}, "event": "charge.success"}	failed	\nInvalid `this.prisma.transaction.create()` invocation in\nC:\\Users\\jomea\\Saarbiz\\saabiz\\dist\\apps\\api\\src\\app\\webhooks\\webhooks.service.js:266:63\n\n  263 if (affiliateId) {\n  264     transactionData.affiliateId = affiliateId;\n  265 }\n→ 266 const transaction = await this.prisma.transaction.create({\n        data: {\n          reference: "paystack_test_roundup_001",\n          amount: 2999,\n          gateway: "paystack",\n          status: "success",\n          buyerEmail: "roundup-test@example.com",\n          product: {\n            connect: {\n              id: "seed-acme-analytics"\n            }\n          },\n          plan: {\n            connect: {\n              id: "seed-acme-analytics-basic"\n            }\n          },\n          platformFee: 299.90000000000003,\n          sellerEarnings: 2699.1,\n          subscriptionId: "cf3f1816-1f08-4f8a-873a-d5e6865ff9a4",\n          ~~~~~~~~~~~~~~\n      ?   id?: String,\n      ?   currency?: String,\n      ?   affiliateId?: String | Null,\n      ?   createdAt?: DateTime,\n      ?   updatedAt?: DateTime,\n      ?   subscription?: SubscriptionCreateNestedOneWithoutTransactionsInput,\n      ?   license?: LicenseCreateNestedOneWithoutTransactionInput,\n      ?   affiliateCommission?: AffiliateCommissionCreateNestedOneWithoutTransactionInput,\n      ?   promotion?: PromotionCreateNestedOneWithoutTransactionsInput\n        }\n      })\n\nUnknown argument `subscriptionId`. Did you mean `subscription`? Available options are marked with ?.	\N	0	\N	\N	2026-08-24 00:57:22.531
1173ce62-22c8-4cc6-8d3e-c2e8b68383eb	paystack	charge.success	paystack_test_roundup_001	1aa30cc845c6da37308f5f0e518e57658674ffa06f3c687795f1224fc6af9209ce5e77a5832367fe95ca265319c84c035eba4f3b1c4d8a74e544321029d4ed12	{\r\n    "event":  "charge.success",\r\n    "data":  {\r\n                 "reference":  "paystack_test_roundup_001",\r\n                 "currency":  "NGN",\r\n                 "amount":  299900,\r\n                 "customer":  {\r\n                                  "email":  "roundup-test@example.com"\r\n                              },\r\n                 "metadata":  {\r\n                                  "affiliateCode":  "",\r\n                                  "productId":  "seed-acme-analytics",\r\n                                  "planId":  "seed-acme-analytics-basic"\r\n                              }\r\n             }\r\n}	{"data": {"amount": 299900, "currency": "NGN", "customer": {"email": "roundup-test@example.com"}, "metadata": {"planId": "seed-acme-analytics-basic", "productId": "seed-acme-analytics", "affiliateCode": ""}, "reference": "paystack_test_roundup_001"}, "event": "charge.success"}	failed	\nInvalid `this.prisma.transaction.create()` invocation in\nC:\\Users\\jomea\\Saarbiz\\saabiz\\dist\\apps\\api\\src\\app\\webhooks\\webhooks.service.js:266:63\n\n  263 if (affiliateId) {\n  264     transactionData.affiliateId = affiliateId;\n  265 }\n→ 266 const transaction = await this.prisma.transaction.create({\n        data: {\n          reference: "paystack_test_roundup_001",\n          amount: 2999,\n          gateway: "paystack",\n          status: "success",\n          buyerEmail: "roundup-test@example.com",\n          product: {\n            connect: {\n              id: "seed-acme-analytics"\n            }\n          },\n          plan: {\n            connect: {\n              id: "seed-acme-analytics-basic"\n            }\n          },\n          platformFee: 299.90000000000003,\n          sellerEarnings: 2699.1,\n          subscriptionId: "cf3f1816-1f08-4f8a-873a-d5e6865ff9a4",\n          ~~~~~~~~~~~~~~\n      ?   id?: String,\n      ?   currency?: String,\n      ?   affiliateId?: String | Null,\n      ?   createdAt?: DateTime,\n      ?   updatedAt?: DateTime,\n      ?   subscription?: SubscriptionCreateNestedOneWithoutTransactionsInput,\n      ?   license?: LicenseCreateNestedOneWithoutTransactionInput,\n      ?   affiliateCommission?: AffiliateCommissionCreateNestedOneWithoutTransactionInput,\n      ?   promotion?: PromotionCreateNestedOneWithoutTransactionsInput\n        }\n      })\n\nUnknown argument `subscriptionId`. Did you mean `subscription`? Available options are marked with ?.	\N	0	\N	\N	2026-08-24 01:02:03.838
da3ded38-9ab8-4c08-817e-58caf3475e8a	paystack	charge.success	paystack_test_roundup_001	1aa30cc845c6da37308f5f0e518e57658674ffa06f3c687795f1224fc6af9209ce5e77a5832367fe95ca265319c84c035eba4f3b1c4d8a74e544321029d4ed12	{\r\n    "event":  "charge.success",\r\n    "data":  {\r\n                 "reference":  "paystack_test_roundup_001",\r\n                 "currency":  "NGN",\r\n                 "amount":  299900,\r\n                 "customer":  {\r\n                                  "email":  "roundup-test@example.com"\r\n                              },\r\n                 "metadata":  {\r\n                                  "affiliateCode":  "",\r\n                                  "productId":  "seed-acme-analytics",\r\n                                  "planId":  "seed-acme-analytics-basic"\r\n                              }\r\n             }\r\n}	{"data": {"amount": 299900, "currency": "NGN", "customer": {"email": "roundup-test@example.com"}, "metadata": {"planId": "seed-acme-analytics-basic", "productId": "seed-acme-analytics", "affiliateCode": ""}, "reference": "paystack_test_roundup_001"}, "event": "charge.success"}	failed	\nInvalid `this.prisma.transaction.create()` invocation in\nC:\\Users\\jomea\\Saarbiz\\saabiz\\dist\\apps\\api\\src\\app\\webhooks\\webhooks.service.js:266:63\n\n  263 if (affiliateId) {\n  264     transactionData.affiliateId = affiliateId;\n  265 }\n→ 266 const transaction = await this.prisma.transaction.create({\n        data: {\n          reference: "paystack_test_roundup_001",\n          amount: 2999,\n          gateway: "paystack",\n          status: "success",\n          buyerEmail: "roundup-test@example.com",\n          product: {\n            connect: {\n              id: "seed-acme-analytics"\n            }\n          },\n          plan: {\n            connect: {\n              id: "seed-acme-analytics-basic"\n            }\n          },\n          platformFee: 299.90000000000003,\n          sellerEarnings: 2699.1,\n          subscriptionId: "cf3f1816-1f08-4f8a-873a-d5e6865ff9a4",\n          ~~~~~~~~~~~~~~\n      ?   id?: String,\n      ?   currency?: String,\n      ?   affiliateId?: String | Null,\n      ?   createdAt?: DateTime,\n      ?   updatedAt?: DateTime,\n      ?   subscription?: SubscriptionCreateNestedOneWithoutTransactionsInput,\n      ?   license?: LicenseCreateNestedOneWithoutTransactionInput,\n      ?   affiliateCommission?: AffiliateCommissionCreateNestedOneWithoutTransactionInput,\n      ?   promotion?: PromotionCreateNestedOneWithoutTransactionsInput\n        }\n      })\n\nUnknown argument `subscriptionId`. Did you mean `subscription`? Available options are marked with ?.	\N	0	\N	\N	2026-08-24 01:02:04.359
a71e1375-2064-498d-9a6d-2a69b403175d	paystack	charge.failed	paystack_test_roundup_001	1aa30cc845c6da37308f5f0e518e57658674ffa06f3c687795f1224fc6af9209ce5e77a5832367fe95ca265319c84c035eba4f3b1c4d8a74e544321029d4ed12	{\r\n    "event":  "charge.failed",\r\n    "data":  {\r\n                 "reference":  "paystack_test_roundup_001"\r\n             }\r\n}	{"data": {"reference": "paystack_test_roundup_001"}, "event": "charge.failed"}	failed	Invalid Paystack signature	\N	0	\N	\N	2026-08-24 01:02:04.431
bd13287c-2241-402e-b4d5-71958e9b272f	paystack	charge.success	paystack_test_roundup_001	1aa30cc845c6da37308f5f0e518e57658674ffa06f3c687795f1224fc6af9209ce5e77a5832367fe95ca265319c84c035eba4f3b1c4d8a74e544321029d4ed12	{\r\n    "event":  "charge.success",\r\n    "data":  {\r\n                 "reference":  "paystack_test_roundup_001",\r\n                 "currency":  "NGN",\r\n                 "amount":  299900,\r\n                 "customer":  {\r\n                                  "email":  "roundup-test@example.com"\r\n                              },\r\n                 "metadata":  {\r\n                                  "affiliateCode":  "",\r\n                                  "productId":  "seed-acme-analytics",\r\n                                  "planId":  "seed-acme-analytics-basic"\r\n                              }\r\n             }\r\n}	{"data": {"amount": 299900, "currency": "NGN", "customer": {"email": "roundup-test@example.com"}, "metadata": {"planId": "seed-acme-analytics-basic", "productId": "seed-acme-analytics", "affiliateCode": ""}, "reference": "paystack_test_roundup_001"}, "event": "charge.success"}	success	\N	\N	0	\N	\N	2026-08-24 01:04:54.347
01724eba-00ab-44b1-9c4e-27dcd3419a86	paystack	charge.success	paystack_test_roundup_001	1aa30cc845c6da37308f5f0e518e57658674ffa06f3c687795f1224fc6af9209ce5e77a5832367fe95ca265319c84c035eba4f3b1c4d8a74e544321029d4ed12	{\r\n    "event":  "charge.success",\r\n    "data":  {\r\n                 "reference":  "paystack_test_roundup_001",\r\n                 "currency":  "NGN",\r\n                 "amount":  299900,\r\n                 "customer":  {\r\n                                  "email":  "roundup-test@example.com"\r\n                              },\r\n                 "metadata":  {\r\n                                  "affiliateCode":  "",\r\n                                  "productId":  "seed-acme-analytics",\r\n                                  "planId":  "seed-acme-analytics-basic"\r\n                              }\r\n             }\r\n}	{"data": {"amount": 299900, "currency": "NGN", "customer": {"email": "roundup-test@example.com"}, "metadata": {"planId": "seed-acme-analytics-basic", "productId": "seed-acme-analytics", "affiliateCode": ""}, "reference": "paystack_test_roundup_001"}, "event": "charge.success"}	duplicate	\N	\N	1	2026-08-24 01:05:18.818	duplicate	2026-08-24 01:04:54.631
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
ae24187b-46a3-4e1b-8843-403e2fba9901	81637025328f211d0a72185f0507d369c711890874c0ecb8fbec85e997b07d2d	2026-02-27 14:16:32.405462-08	20260227221629_init	\N	\N	2026-02-27 14:16:31.162867-08	1
4d579655-bda9-4882-b92b-546d68210b85	346efc4316d3ca703b43a187cc4cbd1a9d758156b2861a3d03ed47455ce25c3c	2026-03-02 23:03:18.782423-08	20260303070317_refactor_payment_config	\N	\N	2026-03-02 23:03:17.562564-08	1
6bbd921c-d3d0-4947-aac0-3a25a040ae5a	4435b3a7b36f62acc9d7b15437a9e8c2f27967e7e8ef1dee0b61caf65695ce90	2026-03-02 23:11:33.298842-08	20260303071132_add_transaction_model	\N	\N	2026-03-02 23:11:33.014508-08	1
475eb57f-ab4d-4a50-b6b5-743d4c8b577f	4e32a02c463164159fdf21ba3aee12c1ed78c675e9a6821c13e2fcb4093f9aad	2026-08-20 06:31:09.506344-07	20260315151131_init_saabiz	\N	\N	2026-08-20 06:31:07.841129-07	1
915a8c0d-5718-4673-95cf-e9ed17c9c8aa	28dfdcc4454deafd664116b63904bb0231c401ad31ba86a1b6cfcf5f46aa08aa	2026-08-20 06:34:05.64672-07	20260820000000_multi_domain_tenants	\N	\N	2026-08-20 06:34:04.600552-07	1
71c8d785-67c4-4403-8ddd-0de55cc8c230	af2bcc794998cb1777539c28410e832dce267d21a59f41391e9ef7c420f8352e	2026-08-23 05:44:58.826566-07	20260822000000_honeypot_licenses	\N	\N	2026-08-23 05:44:56.294812-07	1
d6fbe101-d3fa-4eba-82fe-d0407c70c102	9a757efd63b3a16755d85a3ff20c6378b22bc40c434c181e31638d50223a7ceb	2026-08-23 17:16:15.932574-07	20260823000000_roundup_webhook_events	\N	\N	2026-08-23 17:16:13.146686-07	1
\.


--
-- Name: AffiliateCommission AffiliateCommission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AffiliateCommission"
    ADD CONSTRAINT "AffiliateCommission_pkey" PRIMARY KEY (id);


--
-- Name: AffiliateLink AffiliateLink_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AffiliateLink"
    ADD CONSTRAINT "AffiliateLink_pkey" PRIMARY KEY (id);


--
-- Name: AffiliatePayout AffiliatePayout_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AffiliatePayout"
    ADD CONSTRAINT "AffiliatePayout_pkey" PRIMARY KEY (id);


--
-- Name: Affiliate Affiliate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Affiliate"
    ADD CONSTRAINT "Affiliate_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: BotSubmission BotSubmission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BotSubmission"
    ADD CONSTRAINT "BotSubmission_pkey" PRIMARY KEY (id);


--
-- Name: Domain Domain_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Domain"
    ADD CONSTRAINT "Domain_pkey" PRIMARY KEY (id);


--
-- Name: HoneypotHit HoneypotHit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HoneypotHit"
    ADD CONSTRAINT "HoneypotHit_pkey" PRIMARY KEY (id);


--
-- Name: Honeypot Honeypot_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Honeypot"
    ADD CONSTRAINT "Honeypot_pkey" PRIMARY KEY (id);


--
-- Name: License License_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."License"
    ADD CONSTRAINT "License_pkey" PRIMARY KEY (id);


--
-- Name: Plan Plan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Plan"
    ADD CONSTRAINT "Plan_pkey" PRIMARY KEY (id);


--
-- Name: PlatformConfig PlatformConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PlatformConfig"
    ADD CONSTRAINT "PlatformConfig_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: Promotion Promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Promotion"
    ADD CONSTRAINT "Promotion_pkey" PRIMARY KEY (id);


--
-- Name: Seller Seller_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Seller"
    ADD CONSTRAINT "Seller_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: Tenant Tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Tenant"
    ADD CONSTRAINT "Tenant_pkey" PRIMARY KEY (id);


--
-- Name: Transaction Transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WebhookEvent WebhookEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WebhookEvent"
    ADD CONSTRAINT "WebhookEvent_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AffiliateCommission_transactionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AffiliateCommission_transactionId_key" ON public."AffiliateCommission" USING btree ("transactionId");


--
-- Name: AffiliateLink_affiliateId_productId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AffiliateLink_affiliateId_productId_key" ON public."AffiliateLink" USING btree ("affiliateId", "productId");


--
-- Name: AffiliateLink_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AffiliateLink_code_key" ON public."AffiliateLink" USING btree (code);


--
-- Name: AffiliatePayout_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AffiliatePayout_reference_key" ON public."AffiliatePayout" USING btree (reference);


--
-- Name: Affiliate_affiliateCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Affiliate_affiliateCode_key" ON public."Affiliate" USING btree ("affiliateCode");


--
-- Name: Affiliate_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Affiliate_userId_key" ON public."Affiliate" USING btree ("userId");


--
-- Name: BotSubmission_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "BotSubmission_createdAt_idx" ON public."BotSubmission" USING btree ("createdAt");


--
-- Name: Domain_host_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Domain_host_key" ON public."Domain" USING btree (host);


--
-- Name: HoneypotHit_honeypotId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "HoneypotHit_honeypotId_createdAt_idx" ON public."HoneypotHit" USING btree ("honeypotId", "createdAt");


--
-- Name: Honeypot_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Honeypot_key_key" ON public."Honeypot" USING btree (key);


--
-- Name: Honeypot_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Honeypot_productId_idx" ON public."Honeypot" USING btree ("productId");


--
-- Name: License_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "License_key_key" ON public."License" USING btree (key);


--
-- Name: License_transactionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "License_transactionId_key" ON public."License" USING btree ("transactionId");


--
-- Name: PlatformConfig_tenantId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PlatformConfig_tenantId_key" ON public."PlatformConfig" USING btree ("tenantId");


--
-- Name: Promotion_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Promotion_code_key" ON public."Promotion" USING btree (code);


--
-- Name: Seller_tenantId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Seller_tenantId_key" ON public."Seller" USING btree ("tenantId");


--
-- Name: Seller_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Seller_userId_key" ON public."Seller" USING btree ("userId");


--
-- Name: Tenant_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Tenant_slug_key" ON public."Tenant" USING btree (slug);


--
-- Name: Transaction_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Transaction_reference_key" ON public."Transaction" USING btree (reference);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: WebhookEvent_gateway_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WebhookEvent_gateway_createdAt_idx" ON public."WebhookEvent" USING btree (gateway, "createdAt");


--
-- Name: AffiliateCommission AffiliateCommission_affiliateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AffiliateCommission"
    ADD CONSTRAINT "AffiliateCommission_affiliateId_fkey" FOREIGN KEY ("affiliateId") REFERENCES public."Affiliate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AffiliateCommission AffiliateCommission_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AffiliateCommission"
    ADD CONSTRAINT "AffiliateCommission_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AffiliateCommission AffiliateCommission_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AffiliateCommission"
    ADD CONSTRAINT "AffiliateCommission_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public."Transaction"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AffiliateLink AffiliateLink_affiliateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AffiliateLink"
    ADD CONSTRAINT "AffiliateLink_affiliateId_fkey" FOREIGN KEY ("affiliateId") REFERENCES public."Affiliate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AffiliateLink AffiliateLink_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AffiliateLink"
    ADD CONSTRAINT "AffiliateLink_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AffiliatePayout AffiliatePayout_affiliateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AffiliatePayout"
    ADD CONSTRAINT "AffiliatePayout_affiliateId_fkey" FOREIGN KEY ("affiliateId") REFERENCES public."Affiliate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Affiliate Affiliate_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Affiliate"
    ADD CONSTRAINT "Affiliate_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Domain Domain_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Domain"
    ADD CONSTRAINT "Domain_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: HoneypotHit HoneypotHit_honeypotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HoneypotHit"
    ADD CONSTRAINT "HoneypotHit_honeypotId_fkey" FOREIGN KEY ("honeypotId") REFERENCES public."Honeypot"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Honeypot Honeypot_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Honeypot"
    ADD CONSTRAINT "Honeypot_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: License License_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."License"
    ADD CONSTRAINT "License_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: License License_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."License"
    ADD CONSTRAINT "License_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public."Subscription"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: License License_transactionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."License"
    ADD CONSTRAINT "License_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES public."Transaction"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Plan Plan_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Plan"
    ADD CONSTRAINT "Plan_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PlatformConfig PlatformConfig_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PlatformConfig"
    ADD CONSTRAINT "PlatformConfig_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Product Product_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public."Seller"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Seller Seller_tenantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Seller"
    ADD CONSTRAINT "Seller_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES public."Tenant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Seller Seller_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Seller"
    ADD CONSTRAINT "Seller_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Subscription Subscription_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Transaction Transaction_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Transaction Transaction_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Transaction Transaction_promotionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_promotionId_fkey" FOREIGN KEY ("promotionId") REFERENCES public."Promotion"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Transaction Transaction_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Transaction"
    ADD CONSTRAINT "Transaction_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public."Subscription"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

